# Mushak Run

Mushak Run is a one-button Himalayan endless runner where Ganesha rides Mushak, collects laddus, and grows through four visual stages.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/mushak-run/src/App.tsx` — game state, scene rendering, input handling, growth stages, demo mode, results, hall of fame, and settings.
- `artifacts/mushak-run/src/index.css` — responsive visual system, scene layers, animation, HUD, overlays, and mobile layout.
- `artifacts/mushak-run/public/ganesha-mushak-rider.png` — transparent character sprite used across the menu and gameplay.
- `artifacts/mushak-run/src/components/ui/` — scaffolded shared UI primitives.
- `artifacts/mushak-run/.replit-artifact/artifact.toml` — artifact routing and managed web workflow.

## Architecture decisions

- The game is frontend-only and deliberately local-first: scores, hall-of-fame entries, tutorial completion, and accessibility/audio preferences use guarded localStorage.
- Gameplay uses one shared hop action for pointer, mouse, Space, and Arrow Up so desktop and mobile have the same feel.
- The scene is rendered with lightweight React/CSS primitives and one local transparent rider sprite rather than network assets, keeping the demo portable and fast.
- Growth stages are tied directly to laddu count so the core promise is visible: 5, 12, and 20 laddus unlock the next transformation.

## Product

Players guide Ganesha and Mushak through a layered Himalayan route, hop over fair obstacles, collect glowing laddus, reach four growth stages, and chase a local high score. The game includes a first-run tutorial, attract/demo mode, pause and restart flows, reduced motion, sound/music toggles, responsive touch and keyboard controls, results, and a local top-five hall of fame.

## User preferences

- The game should feel contest-ready, culturally respectful, memorable, mobile-friendly, and more distinctive than a generic Flappy Bird clone.

## Gotchas

- The managed web workflow supplies `PORT` and `BASE_PATH`; use the workflow rather than starting the artifact with a root-level dev command.
- The app intentionally has no backend or external asset dependency. Keep future additions offline-safe unless the product direction changes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
